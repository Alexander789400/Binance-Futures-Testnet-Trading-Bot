# Binance Futures Testnet Trading Bot (CLI)

A simplified Python trading bot that places orders on **Binance USDT-M Futures Testnet**.

Supports:

- Market Orders  
- Limit Orders  
- Stop-Limit Orders (Bonus)

Includes:

- Input validation  
- Structured logging  
- Error handling  
- Clean reusable architecture  

---

## Features

- Place **BUY** and **SELL** orders
- Supports order types:
  - MARKET
  - LIMIT
  - STOP_LIMIT (bonus)
- Logs all requests, responses, and errors into `bot.log`

---

## Requirements

- Python 3.8+
- Binance Futures Testnet account
- API credentials from:

https://testnet.binancefuture.com

---
## MOCK Mode (No API Keys Required)

This bot supports a MOCK mode for safe testing without Binance credentials.

Example:

```bash
python src/cli.py --mock --symbol BTCUSDT --side BUY --type MARKET --qty 0.01



## Installation

### 1. Clone Repository

```bash
git clone https://github.com/Alexander789400/Binance-Futures-Testnet-Trading-Bot
cd BINANCE_BOT

