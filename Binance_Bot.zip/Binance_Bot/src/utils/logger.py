import logging


def setup_logger():
    """
    Creates a logger that saves all bot activity into bot.log
    """

    logging.basicConfig(
        filename="bot.log",
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
    )

    return logging.getLogger("BinanceBot")
