import random
import time


class BinanceFuturesClient:
    """
    Real Binance Futures Testnet Client
    """

    def __init__(self, api_key, api_secret):
        from binance.client import Client

        self.client = Client(api_key, api_secret)
        self.client.FUTURES_URL = "https://testnet.binancefuture.com/fapi"

    def place_order(self, **params):
        return self.client.futures_create_order(**params)


class MockFuturesClient:
    """
    Mock Client (No API Keys Needed)
    Simulates Binance order execution.
    """

    def place_order(self, **params):
        time.sleep(1)

        return {
            "orderId": random.randint(100000, 999999),
            "symbol": params["symbol"],
            "side": params["side"],
            "type": params["type"],
            "status": "FILLED",
            "executedQty": params["quantity"],
            "avgPrice": params.get("price", "MARKET_PRICE"),
        }
