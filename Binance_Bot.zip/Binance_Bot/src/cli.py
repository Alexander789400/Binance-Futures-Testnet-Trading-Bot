import argparse
import os
import sys

# ================= IMPORTS =================
from src.api.client import BinanceFuturesClient, MockFuturesClient

from src.utils.logger import setup_logger
from src.utils.validators import (
    validate_symbol,
    validate_side,
    validate_order_type,
    validate_quantity,
    validate_price
)

from src.orders.market import market_order
from src.orders.limit import limit_order
from src.orders.stop_limit import stop_limit_order


# ================= MAIN FUNCTION =================
def main():
    logger = setup_logger()

    print("\n==============================")
    print("  Binance Futures Trading Bot")
    print("   (REAL + MOCK Testnet Mode)")
    print("==============================\n")

    # ================= CLI ARGUMENTS =================
    parser = argparse.ArgumentParser(
        description="CLI Trading Bot for Binance USDT-M Futures Testnet"
    )

    parser.add_argument("--symbol", required=True,
                        help="Trading pair (example: BTCUSDT)")

    parser.add_argument("--side", required=True,
                        choices=["BUY", "SELL"],
                        help="Order side: BUY or SELL")

    parser.add_argument("--type", required=True,
                        choices=["MARKET", "LIMIT", "STOP_LIMIT"],
                        help="Order type: MARKET / LIMIT / STOP_LIMIT")

    parser.add_argument("--qty", required=True, type=float,
                        help="Quantity (example: 0.01)")

    parser.add_argument("--price", type=float,
                        help="Limit price (required for LIMIT & STOP_LIMIT)")

    parser.add_argument("--stop", type=float,
                        help="Stop trigger price (required for STOP_LIMIT)")

    parser.add_argument("--mock", action="store_true",
                        help="Run bot in MOCK mode (no API keys needed)")

    args = parser.parse_args()

    # ================= VALIDATION =================
    try:
        validate_symbol(args.symbol)
        validate_side(args.side)
        validate_order_type(args.type)
        validate_quantity(args.qty)

        # Extra checks depending on order type
        if args.type == "LIMIT":
            validate_price(args.price)

        if args.type == "STOP_LIMIT":
            validate_price(args.price)
            validate_price(args.stop)

    except ValueError as ve:
        print("\n INPUT VALIDATION ERROR")
        print("➡", ve)
        sys.exit(1)

    # ================= CLIENT SELECTION =================
    if args.mock:
        print(" MODE: MOCK (No Binance API keys required)\n")
        client = MockFuturesClient()

    else:
        print(" MODE: REAL Binance Futures Testnet\n")

        api_key = os.getenv("BINANCE_API_KEY")
        api_secret = os.getenv("BINANCE_API_SECRET")

        if not api_key or not api_secret:
            print(" Missing API keys!")
            print("\nSet keys in terminal first:")
            print("   set BINANCE_API_KEY=your_key")
            print("   set BINANCE_API_SECRET=your_secret")
            print("\nOR run safely in MOCK mode:")
            print("   python src/cli.py --mock ...\n")
            sys.exit(1)

        client = BinanceFuturesClient(api_key, api_secret)

    # ================= ORDER SUMMARY =================
    print(" ORDER REQUEST SUMMARY")
    print("----------------------------")
    print("Symbol     :", args.symbol)
    print("Side       :", args.side)
    print("Type       :", args.type)
    print("Quantity   :", args.qty)

    if args.type in ["LIMIT", "STOP_LIMIT"]:
        print("Limit Price:", args.price)

    if args.type == "STOP_LIMIT":
        print("Stop Price :", args.stop)

    print("----------------------------\n")

    # ================= EXECUTION =================
    try:
        if args.type == "MARKET":
            response = market_order(client, logger,
                                    args.symbol, args.side, args.qty)

        elif args.type == "LIMIT":
            response = limit_order(client, logger,
                                   args.symbol, args.side,
                                   args.qty, args.price)

        elif args.type == "STOP_LIMIT":
            response = stop_limit_order(client, logger,
                                        args.symbol, args.side,
                                        args.qty, args.stop, args.price)

        # ================= SUCCESS OUTPUT =================
        print("\n ORDER PLACED SUCCESSFULLY!")
        print("==============================")
        print("Order ID     :", response.get("orderId"))
        print("Status       :", response.get("status"))
        print("Executed Qty :", response.get("executedQty"))
        print("Avg Price    :", response.get("avgPrice"))
        print("==============================\n")

    except Exception as e:
        logger.error("ORDER FAILED", exc_info=True)

        print("\n ORDER FAILED!")
        print("Reason:", str(e))
        print("Check bot.log for full error trace.\n")


# ================= ENTRY POINT =================
if __name__ == "__main__":
    main()
