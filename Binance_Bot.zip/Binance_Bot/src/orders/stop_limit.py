def stop_limit_order(client, logger, symbol, side, quantity, stop_price, limit_price):
    """
    Places a STOP-LIMIT order
    """

    logger.info("Placing STOP-LIMIT order...")

    params = {
        "symbol": symbol,
        "side": side,
        "type": "STOP",
        "quantity": quantity,
        "stopPrice": stop_price,
        "price": limit_price,
        "timeInForce": "GTC",
    }

    logger.info(f"STOP_LIMIT REQUEST: {params}")

    response = client.place_order(**params)

    logger.info(f"STOP_LIMIT RESPONSE: {response}")

    return response
