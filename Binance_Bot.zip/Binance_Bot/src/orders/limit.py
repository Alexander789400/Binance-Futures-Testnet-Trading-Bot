def limit_order(client, logger, symbol, side, quantity, price):
    """
    Places a LIMIT order
    """

    logger.info("Placing LIMIT order...")

    params = {
        "symbol": symbol,
        "side": side,
        "type": "LIMIT",
        "quantity": quantity,
        "price": price,
        "timeInForce": "GTC",
    }

    logger.info(f"LIMIT REQUEST: {params}")

    response = client.place_order(**params)

    logger.info(f"LIMIT RESPONSE: {response}")

    return response
