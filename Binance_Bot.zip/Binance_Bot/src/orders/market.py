def market_order(client, logger, symbol, side, quantity):
    """
    Places a MARKET order
    """

    logger.info("Placing MARKET order...")

    params = {
        "symbol": symbol,
        "side": side,
        "type": "MARKET",
        "quantity": quantity,
    }

    logger.info(f"MARKET REQUEST: {params}")

    response = client.place_order(**params)

    logger.info(f"MARKET RESPONSE: {response}")

    return response
